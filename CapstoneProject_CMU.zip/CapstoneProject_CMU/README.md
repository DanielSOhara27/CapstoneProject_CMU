# CapstoneProject_CMU
bla

Class Naming Convention
- Initial Cap
- ServicenameServlet
- ServicenameApplication
